// just keep tailwind's intellisense
export default {
  content: [
    './index.html',
    './src/**/*.{ts,tsx,css,html,scss}',
  ],
}
## Pengu Loader UI & Built-in Plugins

This folder includes the app UI and built-in plugins.

```
loader/
  |__ src/
  |__ src-tuari/

  |__ src-plugins
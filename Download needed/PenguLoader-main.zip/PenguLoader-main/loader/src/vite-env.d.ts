/// <reference types="vite/client" />

declare interface Window {
  isMac: boolean
  appVersion: string
}
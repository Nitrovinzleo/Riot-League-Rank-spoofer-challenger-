export interface Data {
  address: string,
  password: string,
  port: number,
  protocol: string,
  username: string
}

export const endpoints = {
  chibiIcon: "/lol-summoner/v1/current-summoner/icon/",
  lolChat: "/lol-chat/v1/me/",
  profile: "/lol-summoner/v1/current-summoner/summoner-profile/",
  friends: "/lol-chat/v1/friends/",
  conversations: "/lol-chat/v1/conversations/",
  lobby: "/lol-lobby/v2/lobby"
};

import { ChampionsPipe } from './champions.pipe';

describe('ChampionsPipe', () => {
  it('create an instance', () => {
    const pipe = new ChampionsPipe();
    expect(pipe).toBeTruthy();
  });
});

export const AppConfig = {
  production: false,
  environment: 'DEV'
};
